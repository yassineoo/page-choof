export const digitalServices = [
  {
    name: "Sécurité",
    icon: "./assets/images/services/security.svg"
  },
  {
    name: "Communauté",
    icon: "./assets/images/services/people.svg"
  },
  {
    name: "Cloud",
    icon: "./assets/images/services/cloud.svg"
  },
  {
    name: "Internet",
    icon: "./assets/images/services/internet.svg"
  },
  {
    name: "Wi-Fi",
    icon: "./assets/images/services/wifi.svg"
  }
];